# 🎮 Secure DayZ Leaderboard with Node.js Backend

A secure, production-ready DayZ leaderboard system with:
- ✅ **Secure backend** - API credentials hidden on server
- ✅ **Beautiful frontend** - Modern, responsive design
- ✅ **Easy embedding** - Drop into any website with iframe
- ✅ **Auto-refresh** - Updates every 5 minutes
- ✅ **CFTools API** - Same reliable method Mirasaki uses

## 📁 Project Structure

```
dayz-leaderboard-secure/
├── server.js              # Node.js backend (secure API proxy)
├── package.json           # Dependencies
├── .env.example           # Environment variables template
├── .env                   # Your actual credentials (DO NOT COMMIT)
├── public/
│   └── index.html         # Frontend widget
└── README.md              # This file
```

## 🚀 Quick Setup Guide

### Step 1: Install Node.js

If you haven't already:
1. Download from: https://nodejs.org/
2. Install the **LTS version**
3. Verify: `node --version` and `npm --version`

### Step 2: Setup the Project

1. **Create project folder:**
   ```bash
   mkdir dayz-leaderboard-secure
   cd dayz-leaderboard-secure
   ```

2. **Extract all files** into this folder

3. **Create your `.env` file:**
   - Copy `.env.example` to `.env`
   - Fill in your CFTools credentials:

   ```env
   CFTOOLS_API_APPLICATION_ID=68fc3e81fa1ea5e6f60411ff
   CFTOOLS_API_SECRET=your_actual_secret_here
   CFTOOLS_SERVER_API_ID=315bc050-1937-4485-8eb3-103a8967de3c
   PORT=3000
   NODE_ENV=production
   ```

4. **IMPORTANT: Authorize your application**
   - Visit: https://app.cftools.cloud/authorize/68fc3e81fa1ea5e6f60411ff
   - Log in and authorize your server
   - ⚠️ This MUST be done or the API won't work!

### Step 3: Install Dependencies

```bash
npm install
```

This installs:
- `express` - Web server
- `cors` - Cross-origin support
- `dotenv` - Environment variables

### Step 4: Run the Server

**Development mode (auto-restarts on changes):**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

You should see:
```
🚀 ================================
🎮 DayZ Leaderboard Server Started
🚀 ================================

✅ Server running on: http://localhost:3000
✅ API endpoint: http://localhost:3000/api/leaderboard
✅ Widget available at: http://localhost:3000
```

### Step 5: Test It!

Open your browser and go to: **http://localhost:3000**

You should see your beautiful leaderboard! 🎉

## 🌐 API Endpoints

### GET /api/health
Check if the server is running.

**Example:**
```
http://localhost:3000/api/health
```

**Response:**
```json
{
  "status": "ok",
  "message": "CFTools Leaderboard API is running",
  "timestamp": "2025-10-25T04:00:00.000Z"
}
```

### GET /api/leaderboard
Get leaderboard data.

**Query Parameters:**
- `stat` - Sort by: `kills`, `kdratio`, `deaths`, `longest_kill`, `longest_shot`, `playtime`, `suicides`
- `order` - `-1` (descending) or `1` (ascending)
- `limit` - Number of players (1-100)

**Examples:**
```
http://localhost:3000/api/leaderboard?stat=kdratio&limit=25
http://localhost:3000/api/leaderboard?stat=kills&limit=10
http://localhost:3000/api/leaderboard?stat=playtime&limit=50
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "latest_name": "PlayerName",
      "kills": 150,
      "deaths": 45,
      "playtime": 54321,
      "longest_kill": 850,
      "longest_shot": 920,
      "suicides": 2
    }
  ],
  "timestamp": "2025-10-25T04:00:00.000Z"
}
```

## 📦 Embedding on Your Website

### Option 1: Direct Link
```html
<a href="http://your-server.com:3000" target="_blank">View Leaderboard</a>
```

### Option 2: Iframe (Recommended)
```html
<iframe 
    src="http://your-server.com:3000?embed=true" 
    width="100%" 
    height="900px" 
    frameborder="0"
    style="border: none; border-radius: 15px;">
</iframe>
```

### Option 3: Fetch API Data
Use the API endpoint to build your own custom display:

```javascript
fetch('http://your-server.com:3000/api/leaderboard?stat=kdratio&limit=10')
  .then(response => response.json())
  .then(data => {
    console.log(data.data); // Array of players
    // Build your custom HTML here
  });
```

## 🎨 Customization

### Change Colors

Edit `public/index.html` around line 30-40:

```css
/* Main theme color */
.leaderboard-header h1 {
    color: #00FFFF; /* Change this */
}

/* Background gradient */
body {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
}
```

### Change Server Name

Edit `public/index.html` around line 338:

```html
<div class="leaderboard-header">
    <h1>🏆 Your Server Name</h1>
    <p>Your Tagline Here</p>
</div>
```

### Change Auto-Refresh Time

Edit `public/index.html` around line 323:

```javascript
const CONFIG = {
    AUTO_REFRESH_SECONDS: 300, // Change this (in seconds)
};
```

## 🚀 Deploying to Production

### Option 1: Keep Running with PM2

Install PM2 (process manager):
```bash
npm install -g pm2
```

Start your server:
```bash
pm2 start server.js --name "dayz-leaderboard"
pm2 save
pm2 startup
```

Your server will now:
- Run in the background
- Auto-restart on crashes
- Start on server reboot

### Option 2: Deploy to Heroku (Free)

1. Install Heroku CLI
2. Login: `heroku login`
3. Create app: `heroku create your-leaderboard`
4. Set environment variables:
   ```bash
   heroku config:set CFTOOLS_API_APPLICATION_ID=your_id
   heroku config:set CFTOOLS_API_SECRET=your_secret
   heroku config:set CFTOOLS_SERVER_API_ID=your_server_id
   ```
5. Deploy:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git push heroku main
   ```

### Option 3: Deploy to VPS (DigitalOcean, AWS, etc.)

1. SSH into your server
2. Install Node.js
3. Clone/upload your project
4. Install dependencies: `npm install`
5. Setup PM2 (see Option 1)
6. Configure nginx reverse proxy (optional but recommended)

**Example nginx config:**
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 🔒 Security Best Practices

1. **Never commit `.env`** - Add it to `.gitignore`
2. **Use environment variables** - Don't hardcode credentials
3. **Use HTTPS in production** - Get free SSL with Let's Encrypt
4. **Rate limiting** - Add express-rate-limit if needed
5. **CORS configuration** - Restrict to your domain in production

Example CORS for specific domain:
```javascript
// In server.js, change this line:
app.use(cors());

// To this:
app.use(cors({
    origin: 'https://your-website.com'
}));
```

## 🐛 Troubleshooting

### Server won't start

**Error: "Cannot find module 'express'"**
```bash
Solution: npm install
```

**Error: "Port 3000 already in use"**
```bash
Solution: Change PORT in .env file or stop other process
```

### Authentication fails

**Error: "Authentication failed: 401"**
```
Solution:
1. Check your credentials in .env
2. Visit the Grant URL to authorize
3. Make sure secret is correct (no extra spaces)
```

### No data returned

**Empty leaderboard**
```
Solution:
1. Verify Server API ID is correct
2. Make sure server has collected stats
3. Check if players have been on the server
```

### CORS errors in browser

**Error: "CORS policy blocked"**
```
Solution:
- If testing locally, access via http://localhost:3000
- In production, configure CORS properly in server.js
```

## 📊 What's Displayed

The leaderboard shows:
- **Rank** - Position (#1, #2, #3, etc.)
- **Player Name** - Latest known in-game name
- **Kills** - Total player kills
- **Deaths** - Total deaths
- **K/D Ratio** - Kill/Death ratio (color-coded)
- **Playtime** - Total time played
- **Longest Kill** - Longest kill distance

## 🎯 Features

- ✅ Secure backend (credentials never exposed to client)
- ✅ Real-time data from CFTools API
- ✅ Auto-refresh every 5 minutes
- ✅ Responsive design (mobile-friendly)
- ✅ Sort by any stat
- ✅ Adjustable player limit (10, 25, 50, 100)
- ✅ Beautiful animations and hover effects
- ✅ Top 3 players highlighted (gold, silver, bronze)
- ✅ Easy to embed anywhere
- ✅ Production-ready

## 📝 Files Explained

### server.js
- Node.js backend server
- Handles CFTools API authentication
- Provides secure API endpoints
- Caches auth tokens for performance

### public/index.html
- Frontend widget
- Calls backend API (no credentials exposed)
- Handles display and user interaction
- Fully self-contained

### .env
- Your configuration and credentials
- **NEVER commit this to git**
- Server-side only

### package.json
- Project dependencies
- npm scripts for running the server

## 🆘 Need Help?

Common issues and solutions are in the Troubleshooting section above.

For CFTools API issues:
- Documentation: https://docs.cftools.cloud/
- Support: https://app.cftools.cloud/support

## 📜 License

MIT License - Feel free to use and modify!

## 🎉 You're Done!

Your secure leaderboard is ready to use! 

**Quick checklist:**
- [x] Node.js installed
- [x] Dependencies installed (`npm install`)
- [x] `.env` file configured
- [x] CFTools app authorized
- [x] Server running (`npm start`)
- [x] Leaderboard working at http://localhost:3000

Enjoy! 🚀
