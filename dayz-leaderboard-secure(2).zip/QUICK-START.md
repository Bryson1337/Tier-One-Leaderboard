# 🚀 Quick Start Commands - Copy & Paste These!

## Step 1: Setup (Do Once)

Open Command Prompt in your project folder and run these commands one by one:

```bash
# Copy .env.example to .env
copy .env.example .env

# Open .env in Notepad to edit
notepad .env
```

**In the .env file that opens:**
- Replace `YOUR_SECRET_HERE` with your actual CFTools secret
- Save and close

## Step 2: Install Dependencies

```bash
npm install
```

Wait for this to complete (takes ~30 seconds).

## Step 3: Start the Server

```bash
npm start
```

You should see:
```
🚀 ================================
🎮 DayZ Leaderboard Server Started
🚀 ================================

✅ Server running on: http://localhost:3000
```

## Step 4: Open in Browser

Open your browser and go to:
```
http://localhost:3000
```

## 🎯 That's It!

Your secure leaderboard is now running!

---

## 📝 Important URLs

**Your Grant URL (authorize this first!):**
https://app.cftools.cloud/authorize/68fc3e81fa1ea5e6f60411ff

**Your Leaderboard:**
http://localhost:3000

**API Endpoint:**
http://localhost:3000/api/leaderboard

---

## 🛑 Stop the Server

Press `Ctrl+C` in the Command Prompt

---

## 🔄 Restart the Server

Just run again:
```bash
npm start
```

---

## 🎨 Embed on Your Website

Add this to your HTML:

```html
<iframe 
    src="http://your-server-ip:3000?embed=true" 
    width="100%" 
    height="900px" 
    frameborder="0"
    style="border: none;">
</iframe>
```

Replace `your-server-ip` with:
- `localhost` if testing locally
- Your actual server IP/domain in production

---

## 📊 Test the API Directly

Open in browser:
```
http://localhost:3000/api/leaderboard?stat=kills&limit=10
```

You should see JSON data!

---

## ✅ Quick Checklist

- [ ] Copied .env.example to .env
- [ ] Filled in CFTools secret in .env
- [ ] Ran `npm install`
- [ ] Authorized app at Grant URL
- [ ] Ran `npm start`
- [ ] Opened http://localhost:3000
- [ ] Leaderboard is showing!

---

## 🆘 Common Issues

**"Cannot find module"**
→ Run: `npm install`

**"Port 3000 in use"**
→ Change PORT=3001 in .env file

**"Authentication failed"**
→ Visit the Grant URL and authorize!

**No data showing**
→ Check Server API ID is correct

---

## 🎉 All Done!

Your secure leaderboard is ready!

Want to make it public? See README.md for deployment options.
